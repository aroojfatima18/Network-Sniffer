#!/usr/bin/env python3
"""
sniffer.py - improved single-file educational packet sniffer (in-place edit)

Features added:
- timestamped output
- shows L3 (IP) and L4 (TCP/UDP/ICMP) details: ports and TCP flags
- optional small payload preview (hex + ASCII), controlled with --show-payload
- basic DNS and plain-HTTP heuristics (only for unencrypted HTTP)
- optional packet count stop (--count)
- safe defaults (no long payload dumps)

Usage examples:
  sudo python3 sniffer.py -i enp0s3
  sudo python3 sniffer.py -i enp0s3 --show-payload --payload-len 120
  sudo python3 sniffer.py -i enp0s3 --count 100
"""
import argparse
import time
import sys
from scapy.all import sniff, Raw
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.dns import DNS, DNSQR

def hexdump_preview(b: bytes, length=64):
    """Return short hex + ASCII preview for bytes b."""
    if not b:
        return ""
    b = b[:length]
    hexpart = " ".join(f"{x:02x}" for x in b)
    ascp = "".join((chr(x) if 32 <= x < 127 else ".") for x in b)
    return f"HEX[{hexpart}] ASCII[{ascp}]"

def parse_packet(pkt, args):
    """Build and print a readable summary for the packet."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # Default summary
    if IP in pkt:
        ip = pkt[IP]
        src = ip.src
        dst = ip.dst
        line = f"[{ts}] {src} -> {dst}"
        # L4: TCP/UDP/ICMP
        if pkt.haslayer(TCP):
            t = pkt[TCP]
            sport, dport = t.sport, t.dport
            flags = t.sprintf("%flags%")
            line += f" | TCP {sport}->{dport}"
            if flags:
                line += f" flags={flags}"
        elif pkt.haslayer(UDP):
            u = pkt[UDP]
            sport, dport = u.sport, u.dport
            line += f" | UDP {sport}->{dport}"
        elif pkt.haslayer(ICMP):
            ic = pkt[ICMP]
            line += f" | ICMP type={ic.type}"
        else:
            line += " | L4=Unknown"
    else:
        line = f"[{ts}] {pkt.summary()}"

    # DNS parsing (basic)
    if pkt.haslayer(DNS):
        dns = pkt[DNS]
        # DNS query
        if getattr(dns, "qdcount", 0) and dns.qr == 0:
            try:
                q = dns[DNSQR]
                qname = q.qname.decode() if isinstance(q.qname, bytes) else q.qname
                line += f" | DNS-Q: {qname}"
            except Exception:
                line += " | DNS-Q"
        elif dns.qr == 1:
            line += " | DNS-RESP"

    # Show payload preview if requested (and if present)
    if args.show_payload and pkt.haslayer(Raw):
        raw = bytes(pkt[Raw])
        preview = hexdump_preview(raw, length=args.payload_len)
        line += f" | PayloadPreview: {preview}"
        # Heuristic: detect simple plaintext HTTP request/response
        try:
            text = raw.decode('utf-8', errors='ignore')
            if text.startswith(("GET ", "POST ", "PUT ", "HEAD ")):
                first_line = text.splitlines()[0]
                line += f" | HTTP-REQ: {first_line}"
            elif text.startswith(("HTTP/1.",)):
                first_line = text.splitlines()[0]
                line += f" | HTTP-RESP: {first_line}"
        except Exception:
            pass

    print(line)

def main():
    parser = argparse.ArgumentParser(description="Educational packet sniffer (scapy)")
    parser.add_argument("-i", "--iface", required=True, help="Interface to sniff (e.g., enp0s3)")
    parser.add_argument("--show-payload", action="store_true", help="Show small payload preview (hex+ASCII)")
    parser.add_argument("--payload-len", type=int, default=64, help="Max bytes to show in payload preview")
    parser.add_argument("--count", type=int, default=0, help="Stop after N packets (0 = run forever)")
    args = parser.parse_args()

    counter = {"n": 0}
    def prn(pkt):
        counter["n"] += 1
        parse_packet(pkt, args)
        if args.count and counter["n"] >= args.count:
            return True  # stop sniffing

    print(f"Starting sniffer on interface {args.iface}. show_payload={args.show_payload}")
    try:
        sniff(iface=args.iface, prn=prn, store=0)
    except PermissionError:
        print("Permission denied: run this script with sudo/root.")
    except KeyboardInterrupt:
        print("\nStopped by user (Ctrl-C). Goodbye.")
    except Exception as e:
        print("Sniffing error:", e)

if __name__ == '__main__':
    main()
PY
